% This is code for Exercises 1 and 2 as part of the Pocket AI
% and IoT workshop presented at the Grace Hopper Celebration 2019

% Use the mobiledev command to create an 
% object that links your mobile device.

m = mobiledev;

% Set the sample rate
m.SampleRate = 60;

% Enable acceleration sensor on the device.

m.AccelerationSensorEnabled = 1;

% Display the mobiledev connection
input('Press enter to start logging, then move for 30 seconds.');

% Start acquiring data

m.Logging = true;

% Now that you have enabled logging, you are
% acquiring sensor data. Please walk around the room
% for 30 seconds. You'll count the number of steps
% that you took in the next part of this exercise.
pauseFor(30);

% Stop acquiring accelerometer data

m.Logging = false;

% 
input('Data collection complete. Press enter to continue.');