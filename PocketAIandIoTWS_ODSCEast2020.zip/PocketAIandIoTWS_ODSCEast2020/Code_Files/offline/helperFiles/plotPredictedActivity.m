function plotPredictedActivity(tWalk, tRun, tIdle, tTransition, windowLength)

% This function plots predicted activity over time

figure;
hold all

% Display a dot for the periods of time when you 
% did each activity (run, walk, idle) or when you
% were in a transiton state
hWalk = scatter(tWalk+windowLength,...
                0*tWalk,'filled');
            
hRun  = scatter(tRun+windowLength,...
                0*tRun, 'filled');
            
hIdle = scatter(tIdle+windowLength,...
                0*tIdle, 'filled');

hTransition = scatter(tTransition+windowLength,...
                      0*tTransition, 'filled');

% Set properties of the display of the figure, 
% including the legend entries, labels, and axis limits
ylim([-5 15]);
set(gca,'TickLength',[0 0])
yticklabels([]);
title('Detected Activity Over Time',...
      'FontSize', 16);
xlabel('Time Step', 'FontSize', 16);
xAX = get(gca,'XAxis');
set(xAX,'FontSize', 14)
yAX = get(gca,'YAxis');
yAX.Visible = 'off';
% Add legend to the graph
lgd = legend([hWalk, hRun, hIdle, hTransition], ...
    'Walking','Running','Idle',...        
    'Transition', 'FontSize', 14); 
hold off
set(gcf,'color','w');
