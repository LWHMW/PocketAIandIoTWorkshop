% This script is used to establish connection with your Android phone
% (after the required MATLAB Mobile App) is installed. After establishing
% connection from MATLAB to your phone, this App will turn on the
% accelerometer and start collecting acceleration data from your phone. 
% Follow instructions displayed during execution of this code to
% successfully record training data.
%
% Copyright 2014-2019 The MathWorks, Inc.

addpath(fullfile(pwd,'helperFiles'));

userID = input('Enter user ID and press ENTER to start data collection','s');
if isempty(userID)
    userID = 'anon';
end


windowLength = 5;
uniformSampleRate = 60;

mobileSensor = mobiledev();
mobileSensor.SampleRate = uniformSampleRate;
mobileSensor.AccelerationSensorEnabled = 1;

activity = ['walk          '; ...
            'run           '; ...
            'idle          '; ...
            'climb upstairs'; ...
            'go downstairs '];
activityName = char(cellstr(activity));

for i = 1:size(activityName, 1)

    input(['Put your phone in pocket, press ENTER, then ',...
        upper(deblank(activityName(i, :))), ' for 15 seconds.']);
    mobileSensor.Logging = 1;
    pauseFor(15);
    mobileSensor.Logging = 0;
    
    [a, t] = accellog(mobileSensor);
    
    % Checking tWindow is monotonically increasing
    dt = diff(t);
    deleteIndex = find(dt <= 0);
    while (sum(deleteIndex) > 0)
        t(deleteIndex + 1) = [];
        a(deleteIndex + 1,:) = [];
        dt = diff(t);
        deleteIndex = find(dt <= 0);
    end

    fileName = [userID '_' deblank(activityName(i, :)), '.mat'];
    save(fileName, 'a', 't');
    
    feature{i} = extractTrainingFeature(fileName, windowLength, ...
                                            uniformSampleRate);
end

featureWalk = feature{1};
featureRun = feature{2};
featureIdle = feature{3};
featureUp = feature{4};
featureDown = feature{5};
save([userID '_TrainingData.mat'],'featureWalk', 'featureRun', 'featureIdle', ...
     'featureUp', 'featureDown');

disp('Congratulations! You finished recording training data.');
