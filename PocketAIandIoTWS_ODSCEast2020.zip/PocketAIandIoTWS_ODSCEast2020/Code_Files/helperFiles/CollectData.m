% This is code for Exercises 1 and 2 as part of the Pocket AI
% and IoT workshop presented at the Grace Hopper Celebration 2019

function m = CollectData(sampleRate, secs)

% Use the mobiledev command to create an 
% object that links your mobile device.

m = mobiledev;

% Set the sample rate
m.SampleRate = sampleRate;

% Enable acceleration sensor on the device.

m.AccelerationSensorEnabled = 1;

% Display the mobiledev connection
input(sprintf('Press Return to start logging, then move for %d seconds.', secs));

% Start acquiring data

m.Logging = true;

% Now that you have enabled logging, you are
% acquiring sensor data. Please walk around the room
% for the amount of time shown. You'll count the number of steps
% that you took in the next part of this exercise.
pauseFor(secs);

% Stop acquiring accelerometer data

m.Logging = false;

disp('Data collection complete.');
