function pauseFor(n)

iters = n/2;
for i=1:iters
    pause(2);
end

end